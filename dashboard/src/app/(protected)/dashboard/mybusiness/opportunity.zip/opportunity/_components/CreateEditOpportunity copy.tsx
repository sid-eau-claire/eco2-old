import React, { useState, useEffect } from 'react';
import { ChevronDown, ChevronUp, Users, FileText, ListChecks, LayoutDashboard } from 'lucide-react';
import { createOpportunity, updateOpportunity, getClients, getClientsByProfileId, getOpportunityById, deleteOpportunity } from './../_actions/opportunities';
import History from './History';
import ActivityComponent from './Activity';
import Notes from './Notes';
import Files from './Files';
import MeetingScheduler from './MeetingScheduler';
import Calendar from './Calendar';
import { FaFileAlt, FaStickyNote, FaCalendarAlt, FaFolder } from 'react-icons/fa';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { randomBytes } from 'crypto';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog";
import {Loader} from '@/components/Common';

type OpportunityData = {
  profileId: string;
  description: string;
  type: 'Insurance' | 'Investment' | 'Affiliate';
  estAmount: number;
  status: 'Prospect' | 'Discovery' | 'Planning' | 'Plan Ready' | 'Pending Close' | 'Paper Work' | 'In The Mill';
  clientId: string;
  intent: 'Good' | 'Stuck' | 'Lost';
  activities: Activity[];
  planningOptions: string;
  carrierId: string;
  productCategoryId: string;
  fundCategoryTypeId: string;
  notes: Note[];
  documents: File[];
};

type Activity = {
  id?: string;
  type: 'Call' | 'Meeting' | 'Task' | 'Deadline' | 'Email' | 'Lunch';
  subject: string;
  startDate: Date;
  endDate: Date;
  priority: 'Low' | 'Medium' | 'High';
  location: string;
  videoCallLink: string;
  description: string;
  status: 'Free' | 'Busy' | 'Out of Office';
  notes: string;
  participants: { name: string; email: string }[];
};

type Note = {
  id: string;
  content: string;
  createdAt: Date;
};

type File = {
  id: string;
  name: string;
  url: string;
  size: number;
  type: string;
  uploadedAt: Date;
};

type HistoryItem = {
  id: string;
  type: 'activity' | 'note' | 'email' | 'file' | 'document' | 'invoice' | 'changelog';
  title: string;
  date: Date;
  creator: string;
  content?: string;
  participants?: string[];
  relatedItems?: string[];
};

const CreateEditOpportunity = ({ profileId, opportunityId = null, setShowAddRecord, setRefreshData }: { profileId: string; opportunityId?: string | null; setShowAddRecord: any, setRefreshData: any }) => {
  const [expanded, setExpanded] = useState({
    client: true,
    description: true,
    planningOptions: true,
    details: true,
    new: true,
    history: true,
  });
  const [isLoading, setIsLoading] = useState(false);

  const tabs = [
    'Activity', 'Notes', 'Meeting scheduler', 'Documents'
  ];

  const tabIcons: { [key: string]: JSX.Element } = {
    Activity: <FaFileAlt size={18} />,
    Notes: <FaStickyNote size={18} />,
    'Meeting scheduler': <FaCalendarAlt size={18} />,
    Documents: <FaFolder size={18} />
  };

  const getIconForTab = (tab: string) => tabIcons[tab] || <FaFileAlt size={18} />;

  const [historyItems, setHistoryItems] = useState<HistoryItem[]>([]);
  const [opportunityData, setOpportunityData] = useState<OpportunityData>({
    profileId: profileId,
    description: '',
    type: 'Insurance',
    estAmount: 0,
    status: 'Prospect',
    clientId: '',
    intent: 'Good',
    activities: [],
    planningOptions: '',
    carrierId: '',
    productCategoryId: '',
    fundCategoryTypeId: '',
    notes: [],
    documents: []
  });

  const [clients, setClients] = useState<any[]>([]);
  const [activeTab, setActiveTab] = useState('Activity');
  const [selectedAction, setSelectedAction] = useState<string | null>(null);

  const [newActivity, setNewActivity] = useState<Activity>({
    type: 'Call',
    subject: '',
    startDate: new Date(),
    endDate: new Date(Date.now() + 3600000),
    priority: 'Medium',
    location: '',
    videoCallLink: '',
    description: '',
    status: 'Free',
    notes: '',
    participants: []
  });
  
  const [selectedDate, setSelectedDate] = useState(new Date());
  const [calendarStartTime, setCalendarStartTime] = useState(9);
  const [calendarEndTime, setCalendarEndTime] = useState(18);
  const [errorDialogOpen, setErrorDialogOpen] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);

  const planningOptionsChoices = [
    { value: 'Life Insurance Solutions', label: 'Life Insurance Solutions' },
    { value: 'Retirement Planning', label: 'Retirement Planning' },
    { value: 'Kid Education', label: 'Kid Education' }
  ];

  useEffect(() => {
    const fetchClients = async () => {
      const clientsData = await getClients(profileId);
      setClients(clientsData);
    };

    fetchClients();
  }, [profileId]);

  useEffect(() => {
    const fetchOpportunityData = async () => {
      if (opportunityId) {
        try {
          const data = await getOpportunityById(opportunityId);
          setOpportunityData({
            ...data,
            clientId: data?.clientId?.id.toString(),
            profileId: data?.profileId?.id.toString()
          });
          setHistoryItems([
            ...(data.activities || []).map((activity: any) => ({
              id: activity.id || '',
              type: 'activity',
              title: activity.subject,
              date: new Date(activity.startDate),
              creator: activity.participants[0]?.name || 'Unknown',
              content: activity.description,
              participants: activity.participants.map((p: any) => p.name),
            })),
            ...(data.notes || []).map((note: any) => ({
              id: note.id,
              type: 'note',
              title: 'Note',
              date: new Date(note.createdAt),
              creator: 'System',
              content: note.content,
            })),
            ...(data.documents || []).map((doc: any) => ({
              id: doc.id,
              type: 'document',
              title: doc.name,
              date: new Date(doc.uploadedAt),
              creator: 'System',
            })),
          ].sort((a, b) => b.date.getTime() - a.date.getTime()));
        } catch (error) {
          console.error('Error fetching opportunity data:', error);
        }
        setIsLoading(false);
      } else {
        setIsLoading(false);
      }
    };
    setIsLoading(true);
    fetchOpportunityData();
  }, [opportunityId]);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement> | { target: { name: string; value: string | Date } }) => {
    const { name, value } = e.target;
    console.log(`Updating ${name} with value:`, value);
    setOpportunityData(prev => {
      const newData = { ...prev, [name]: value };
      console.log("New opportunityData:", newData);
      return newData;
    });
  };

  const handleActivityInputChange = (e: { target: { name: string; value: any } }) => {
    const { name, value } = e.target;
    setNewActivity(prev => ({ ...prev, [name]: value }));
  };

  const handlePlanningOptionsChange = (selectedOptions: string) => {
    setOpportunityData(prev => ({
      ...prev,
      planningOptions: selectedOptions
    }));
  };

  const handleAddActivity = async (newActivity: Activity) => {
    console.log('newActivity:', newActivity);
    if (!opportunityId) {
      console.error('No opportunity ID available');
      return;
    }
    try {
      setOpportunityData(prev => ({
        ...prev,
        activities: [...(prev.activities || []), newActivity]
      }));
      setNewActivity({
        type: 'Call',
        subject: '',
        startDate: new Date(),
        endDate: new Date(Date.now() + 3600000),
        priority: 'Medium',
        location: '',
        videoCallLink: '',
        description: '',
        status: 'Free',
        notes: '',
        participants: []
      });
      setSelectedAction(null);
      setRefreshData('refresh1');
    } catch (error) {
      console.error('Failed to add activity:', error);
    }
  };

  const handleNoteAdded = async (newNote: Omit<Note, 'id' | 'createdAt'>) => {
    setOpportunityData(prev => ({
      ...prev,
      notes: [...(prev.notes || []), { ...newNote, id: Date.now().toString(), createdAt: new Date() }]
    }));
  };

  const handleFileAdded = async (fileInfo: { name: string; type: string; size: number }, fileContentBase64: string) => {
    setOpportunityData(prev => ({
      ...prev,
      documents: [...(prev.documents || []), { ...fileInfo, id: Date.now().toString(), url: '', uploadedAt: new Date() }]
    }));
  };

  const handleFileDeleted = async (fileId: string) => {
    setOpportunityData(prev => ({
      ...prev,
      documents: (prev.documents || []).filter(file => file.id !== fileId)
    }));
  };

  const toggleSection = (section: keyof typeof expanded) => {
    setExpanded(prev => ({ ...prev, [section]: !prev[section] }));
  };

  const handleActionClick = (action: string) => {
    setSelectedAction(action);
    setNewActivity(prev => ({ ...prev, type: action as Activity['type'] }));
  };

  const updateCalendarTimeRange = (date: Date) => {
    const startHour = date.getHours();
    const endHour = new Date(date.getTime() + 3600000).getHours();
    setCalendarStartTime(Math.max(0, startHour - 1));
    setCalendarEndTime(Math.min(24, endHour + 1));
  };

  const selectedClient = clients.find((client: any) => client.id.toString() === opportunityData.clientId?.toString());
  
  const handleActivityChange = (updatedActivity: Partial<Activity>) => {
    setNewActivity(prev => ({
      ...prev,
      ...updatedActivity
    }));
  };

  const handleDelete = async () => {
    if (opportunityId && opportunityData.status === 'Prospect') {
      try {
        await deleteOpportunity(opportunityId);
        setShowAddRecord(false);
        setRefreshData(randomBytes(1).toString('hex'));
      } catch (error: any) {
        console.error('Error deleting opportunity:', error);
        setErrorMessage(error.message || 'An error occurred while deleting the opportunity.');
        setErrorDialogOpen(true);
      }
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    const updatedOpportunityData = {
      ...opportunityData,
      activities: [...(opportunityData.activities || []), newActivity],
    };
    console.log('updatedOpportunityData:', updatedOpportunityData);
    try {
      if (opportunityId) {
        await updateOpportunity(opportunityId, updatedOpportunityData);
      } else {
        await createOpportunity(updatedOpportunityData);
      }
      setShowAddRecord(false);
      setRefreshData(randomBytes(1).toString('hex'));
    } catch (error: any) {
      console.error('Error saving opportunity:', error);
      setErrorMessage(error.message || 'An error occurred while saving the opportunity.');
      setErrorDialogOpen(true);
    }
  };
  console.log('clients:', clients);
  console.log('opportunityData:', opportunityData);
  return (
    <>
      {isLoading ? <Loader /> : (
        <div className="w-full bg-background pl-[2rem]">
          <form onSubmit={handleSubmit} className="h-full flex flex-col">
            <Card>
              <CardHeader>
                <h3 className='text-xl font-semibold'>Opportunity</h3>
              </CardHeader>
              <CardContent className='flex-1 flex'>
                <aside className="w-1/5 p-4 border">
                  <Section title="Client" icon={<Users size={18} />} expanded={expanded.client} onToggle={() => toggleSection('client')}>
                    <TooltipProvider>
                      <Tooltip>
                        <TooltipTrigger asChild>
                          <Select 
                            onValueChange={(value) => {
                              console.log("Selected value:", value);
                              setOpportunityData(prev => ({ ...prev, clientId: value }));
                            }} 
                            value={opportunityData.clientId?.toString() || ""}
                          >
                            <SelectTrigger className="w-full">
                              <SelectValue>
                                {selectedClient
                                  ? `${selectedClient.firstName} ${selectedClient.lastName}`
                                  : "Select a client"}
                              </SelectValue>
                            </SelectTrigger>
                            <SelectContent className="z-[9999]">
                              {clients && clients.map((client: any, index: number) => (
                                <SelectItem key={index} value={client.id.toString()}>
                                  {client.firstName} {client.lastName}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                        </TooltipTrigger>
                        <TooltipContent>
                          Select a client for this opportunity
                        </TooltipContent>
                      </Tooltip>
                    </TooltipProvider>
                  </Section>          
                  <Section title="Description" icon={<FileText size={18} />} expanded={expanded.description} onToggle={() => toggleSection('description')}>
                    <TooltipProvider>
                      <Tooltip>
                        <TooltipTrigger asChild>
                          <Textarea
                            name="description"
                            value={opportunityData.description}
                            onChange={handleInputChange}
                            placeholder="Description"
                            className="mt-2"
                          />
                        </TooltipTrigger>
                        <TooltipContent>
                          Provide a description for this opportunity
                        </TooltipContent>
                      </Tooltip>
                    </TooltipProvider>
                  </Section>
                  <Section 
                    title="Planning Options" 
                    icon={<ListChecks size={18} />} 
                    expanded={expanded.planningOptions} 
                    onToggle={() => toggleSection('planningOptions')}
                  >
                    <TooltipProvider>
                      <Tooltip>
                        <TooltipTrigger asChild>
                          <div>
                            <Select 
                              onValueChange={(value) => handlePlanningOptionsChange(value)} 
                              value={opportunityData && opportunityData?.planningOptions || ""}
                            >
                              <SelectTrigger className="w-full">
                                <SelectValue placeholder="Select planning options" />
                              </SelectTrigger>
                              <SelectContent className='z-9999'>
                                {planningOptionsChoices.map(option => (
                                  <SelectItem key={option.value} value={option.value}>
                                    {option.label}
                                  </SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                          </div>
                        </TooltipTrigger>
                        <TooltipContent>
                          Select planning options for this opportunity
                        </TooltipContent>
                      </Tooltip>
                    </TooltipProvider>
                  </Section>
                  <Section title="Details" icon={<LayoutDashboard size={18} />} expanded={expanded.details} onToggle={() => toggleSection('details')}>
                    <div className="space-y-2 mt-2">
                      <TooltipProvider>
                        <Tooltip>
                          <TooltipTrigger asChild>
                            <Select onValueChange={(value) => handleInputChange({ target: { name: 'type', value } })} value={opportunityData.type}>
                              <SelectTrigger className="w-full">
                                <SelectValue placeholder="Select opportunity type" />
                              </SelectTrigger>
                              <SelectContent className='z-9999'>
                                <SelectItem value="Insurance">Insurance</SelectItem>
                                <SelectItem value="Investment">Investment</SelectItem>
                                <SelectItem value="Affiliate">Affiliate</SelectItem>
                              </SelectContent>
                            </Select>
                          </TooltipTrigger>
                          <TooltipContent>
                            Select the type of opportunity
                          </TooltipContent>
                        </Tooltip>
                      </TooltipProvider>
                      <TooltipProvider>
                        <Tooltip>
                          <TooltipTrigger asChild>
                            <Select onValueChange={(value) => handleInputChange({ target: { name: 'status', value } })} value={opportunityData.status}>
                              <SelectTrigger className="w-full">
                                <SelectValue placeholder="Select opportunity status" />
                              </SelectTrigger>
                              <SelectContent className='z-9999'>
                                <SelectItem value="Prospect">Prospect</SelectItem>
                                <SelectItem value="Discovery">Discovery</SelectItem>
                                <SelectItem value="Planning">Planning</SelectItem>
                                <SelectItem value="Plan Ready">Plan Ready</SelectItem>
                                <SelectItem value="Pending Close">Pending Close</SelectItem>
                                <SelectItem value="Paper Work">Paper Work</SelectItem>
                                <SelectItem value="In The Mill">In The Mill</SelectItem>
                              </SelectContent>
                            </Select>
                          </TooltipTrigger>
                          <TooltipContent>
                            Select the current status of the opportunity
                          </TooltipContent>
                        </Tooltip>
                      </TooltipProvider>
                      <TooltipProvider>
                        <Tooltip>
                          <TooltipTrigger asChild>
                            <Input
                              type="number"
                              name="estAmount"
                              value={opportunityData.estAmount}
                              onChange={handleInputChange}
                              placeholder="Estimated Amount"
                            />
                          </TooltipTrigger>
                          <TooltipContent>
                            Enter the estimated amount for this opportunity
                          </TooltipContent>
                        </Tooltip>
                      </TooltipProvider>
                      <TooltipProvider>
                        <Tooltip>
                          <TooltipTrigger asChild>
                            <Select onValueChange={(value) => handleInputChange({ target: { name: 'intent', value } })} value={opportunityData.intent}>
                              <SelectTrigger className="w-full">
                                <SelectValue placeholder="Select intent" />
                              </SelectTrigger>
                              <SelectContent className='z-9999'>
                                <SelectItem value="Good">Good</SelectItem>
                                <SelectItem value="Stuck">Stuck</SelectItem>
                                <SelectItem value="Lost">Lost</SelectItem>
                              </SelectContent>
                            </Select>
                          </TooltipTrigger>
                          <TooltipContent>
                            Select the intent for this opportunity
                          </TooltipContent>
                        </Tooltip>
                      </TooltipProvider>
                    </div>
                  </Section>
                  <div className="bg-background p-4 border-t flex flex-col justify-center items-center space-y-4">
                    <Button type="submit" className="w-[10rem] bg-success">Save Opportunity</Button>
                    <Button type="button" className="w-[10rem] bg-orange-500"
                      onClick={() => setShowAddRecord(false)} 
                    >
                      Cancel
                    </Button>
                    {opportunityId && opportunityData.status === 'Prospect' && (
                      <Button type="button" className="w-[10rem] bg-destructive"
                        onClick={() => setDeleteDialogOpen(true)}
                      >
                        Delete Opportunity
                      </Button>
                    )}
                  </div>
                </aside>
                <main className="flex-1 overflow-hidden flex bg-tremor-background-subtle border-t-1">
                  <div className="flex-1 overflow-y-auto p-4 space-y-4">
                    <Card className='pt-4'>
                      <CardContent>
                        <Section title="New" icon={<FaFileAlt size={18} />} expanded={expanded.new} onToggle={() => toggleSection('new')}>
                          <Tabs defaultValue="Activity" className="w-full">
                            <TabsList>
                              {tabs.map((tab, index) => (
                                <TabsTrigger key={index} value={tab} onClick={() => setActiveTab(tab)}>
                                  {getIconForTab(tab)} <span>{tab}</span>
                                </TabsTrigger>
                              ))}
                            </TabsList>
                            <TabsContent value="Activity">
                              <ActivityComponent
                                newActivity={newActivity}
                                handleActivityInputChange={handleActivityInputChange}
                                handleActionClick={handleActionClick}
                                selectedAction={selectedAction}
                                handleAddParticipant={() => {
                                  setNewActivity(prev => ({
                                    ...prev,
                                    participants: [...prev.participants, { name: '', email: '' }]
                                  }));
                                }}
                                handleParticipantChange={(index, field, value) => {
                                  setNewActivity(prev => {
                                    const updatedParticipants = [...prev.participants];
                                    updatedParticipants[index] = { ...updatedParticipants[index], [field]: value };
                                    return { ...prev, participants: updatedParticipants };
                                  });
                                }}
                                handleRemoveParticipant={(index) => {
                                  setNewActivity(prev => ({
                                    ...prev,
                                    participants: prev.participants.filter((_, i) => i !== index)
                                  }));
                                }}
                                handleAddActivity={handleAddActivity}
                                setNewActivity={setNewActivity}
                                handleActivityChange={handleActivityChange}
                                updateCalendarTimeRange={updateCalendarTimeRange}
                                setSelectedDate={setSelectedDate}
                                clientName={selectedClient ? `${selectedClient.firstName} ${selectedClient.lastName}` : ''}
                                clientEmail={selectedClient ? selectedClient.email : ''}
                              />
                            </TabsContent>
                            <TabsContent value="Notes">
                              <Notes
                                opportunityId={opportunityId || ''}
                                notes={[]}
                                onNoteAdded={handleNoteAdded}
                              />
                            </TabsContent>
                            <TabsContent value="Meeting scheduler">
                              <MeetingScheduler />
                            </TabsContent>
                            <TabsContent value="Documents">
                              <Files
                                opportunityId={opportunityId || ''}
                                files={[]}
                                onFileAdded={handleFileAdded}
                                onFileDeleted={handleFileDeleted}
                              />
                            </TabsContent>
                          </Tabs>
                        </Section>
                      </CardContent>
                    </Card>
                    <Card className='pt-4'>
                      <CardContent>
                        <Section title="History" icon={<FaFileAlt size={18} />} expanded={expanded.history} onToggle={() => toggleSection('history')}>
                          <History items={historyItems} />  
                        </Section>
                      </CardContent>
                    </Card>                
                  </div>
                </main>
                <aside className='w-1/5 border-l'>
                  <Calendar
                    selectedDate={selectedDate}
                    setSelectedDate={setSelectedDate}
                    newActivity={newActivity}
                    calendarStartTime={calendarStartTime}
                    calendarEndTime={calendarEndTime}
                  />          
                </aside>
              </CardContent>
            </Card>
          </form>
          <AlertDialog open={errorDialogOpen} onOpenChange={setErrorDialogOpen}>
            <AlertDialogContent>
              <AlertDialogHeader>
                <AlertDialogTitle>Error</AlertDialogTitle>
                <AlertDialogDescription>{errorMessage}</AlertDialogDescription>
              </AlertDialogHeader>
              <AlertDialogFooter>
                <AlertDialogAction onClick={() => setErrorDialogOpen(false)}>OK</AlertDialogAction>
              </AlertDialogFooter>
            </AlertDialogContent>
          </AlertDialog>
          <AlertDialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
            <AlertDialogContent>
              <AlertDialogHeader>
                <AlertDialogTitle>Confirm Deletion</AlertDialogTitle>
                <AlertDialogDescription>
                  Are you sure you want to delete this opportunity? This action cannot be undone.
                </AlertDialogDescription>
              </AlertDialogHeader>
              <AlertDialogFooter>
                <AlertDialogCancel>Cancel</AlertDialogCancel>
                <AlertDialogAction onClick={handleDelete}>Delete</AlertDialogAction>
              </AlertDialogFooter>
            </AlertDialogContent>
          </AlertDialog>
        </div>
      )}
    </>
  );
};

const Section: React.FC<{ title: string; icon: React.ReactNode; expanded: boolean; onToggle: () => void; children: React.ReactNode }> = ({ title, icon, expanded, onToggle, children }) => (
  <div className="border-b pb-4">
    <div className="flex justify-between items-center cursor-pointer" onClick={onToggle}>
      <div className="flex items-center">
        {icon}
        <h2 className="text-lg font-semibold ml-2">{title}</h2>
      </div>
      {expanded ? <ChevronUp size={18} /> : <ChevronDown size={18} />}
    </div>
    {expanded && <div className="mt-2">{children}</div>}
  </div>
);

export default CreateEditOpportunity;