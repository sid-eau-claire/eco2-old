// File: OpportunityCalendar.tsx
import React, { useState } from 'react';
import Calendar from './Calendar';

interface OpportunityCalendarProps {
  newActivity: any;
  setNewActivity: React.Dispatch<React.SetStateAction<any>>;
}

const OpportunityCalendar: React.FC<OpportunityCalendarProps> = ({ newActivity, setNewActivity }) => {
  const [selectedDate, setSelectedDate] = useState(new Date());
  const [calendarStartTime, setCalendarStartTime] = useState(9);
  const [calendarEndTime, setCalendarEndTime] = useState(18);

  const updateCalendarTimeRange = (date: Date) => {
    const startHour = date.getHours();
    const endHour = new Date(date.getTime() + 3600000).getHours();
    setCalendarStartTime(Math.max(0, startHour - 1));
    setCalendarEndTime(Math.min(24, endHour + 1));
  };

  const handleDateChange = (date: Date) => {
    setSelectedDate(date);
    updateCalendarTimeRange(date);
    setNewActivity(prev => ({
      ...prev,
      startDate: date,
      endDate: new Date(date.getTime() + 3600000) // 1 hour later
    }));
  };

  return (
    <aside className='w-1/5 border-l'>
      <Calendar
        selectedDate={selectedDate}
        setSelectedDate={handleDateChange}
        newActivity={newActivity}
        calendarStartTime={calendarStartTime}
        calendarEndTime={calendarEndTime}
      />
    </aside>
  );
};

export default OpportunityCalendar;