'use client'
import React, { useEffect, useRef, useState } from 'react';
import { Input, Select, Switch } from '@/components/Input';
import { useFieldArray } from 'react-hook-form';
import { ColContainer, RowContainer } from '@/components/Containers';
import { getCarriers, getProvinces, getClients } from '../_actions/retrievedata';
import { RoundButton } from '@/components/Button';
import { MdAddCircle, MdSearch } from "react-icons/md";
import { IoCloseCircle } from "react-icons/io5";
import { SearchBox } from '@/components/Common';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import Link from 'next/link';

const CarrierApplicant = ({ form, currentStep, setCurrentStep, markComplete, isEditable, advisor }: { form: any, currentStep: number, setCurrentStep: any, markComplete: any, isEditable?: boolean, advisor: string }) => {
  const { register, control, setValue, watch, formState: { errors, isSubmitting }, reset } = form;
  const formData = watch();
  const [dialogOpen, setDialogOpen] = useState(false);
  const [carriers, setCarriers] = React.useState([]);
  const [provinces, setProvinces] = React.useState([]);
  const [clients, setClients] = React.useState([]);
  const [logoUrl, setLogoUrl] = React.useState('/images/eauclaire/ECO_Logo_Golden.svg');
  const [isComplete, setIsComplete] = React.useState(false);
  const [isCarrierComplete, setIsCarrierComplete] = React.useState(false);
  const completionRef = useRef(false);
  const initializedRef = useRef(false);
  const { fields, append, remove, replace } = useFieldArray({
    control,
    name: 'applicants'
  });
  const insuredAnnuitantWatchFields = fields.map((field, index) => watch(`applicants[${index}].isInsuredAnnuitant`));

  // State for search
  const [searchResults, setSearchResults] = useState<any[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [currentApplicantIndex, setCurrentApplicantIndex] = useState(0);

  useEffect(() => {
    const fetchCarriers = async () => {
      const response = await getCarriers();
      setCarriers(response as any);
    };
    const fetchProvinces = async () => {
      const response = await getProvinces();
      setProvinces(response);
    };
    const fetchClients = async () => {
      const response = await getClients(advisor);
      setClients(response as any);
    };
    fetchCarriers();
    fetchProvinces();
    fetchClients();    
  }, []);

  useEffect(() => {
    if (!initializedRef.current) {
      if (formData.applicants && formData.applicants.length > 0) {
        replace(formData.applicants);
        initializedRef.current = true;
      } else if (fields.length === 0) {
        append({ firstName: '', lastName: '', dateOfBirth: null, gender: null, isInsuredAnnuitant: false, isOwner: false, clientId: null });
        initializedRef.current = true;
      }
    }
  }, [formData.applicants, fields, append, replace]);

  useEffect(() => {
    setIsCarrierComplete(formData?.appInfo?.carrierId && formData?.appInfo?.appNumber && formData?.appInfo?.provinceId && formData?.appInfo?.type)
    const applicants = formData.applicants || [];
    const allFieldsFilled = applicants.every((applicant: any) => 
      applicant.firstName && applicant.lastName && applicant.dateOfBirth && 
      (applicant.gender === 'male' || applicant.gender === 'female')
    );
    const allAffiliateFieldsFilled = applicants.every((applicant: any) => 
      applicant.firstName && applicant.lastName && applicant.email && applicant.phone
    );    
    const hasOwner = applicants.some((applicant: any) => applicant.isOwner);
    let hasInsuredAnnuitant = applicants.some((applicant: any) => applicant.isInsuredAnnuitant);
    if (formData?.appInfo?.carrierName == 'Brownstone Asset Management') {
      hasInsuredAnnuitant = true;
    }
    const isComplete = allFieldsFilled && hasOwner && hasInsuredAnnuitant && isCarrierComplete

    if ((isComplete || allAffiliateFieldsFilled) && !completionRef.current) {
      completionRef.current = true;
      formData.applicants?.forEach((applicant: any, index: number) => {
        if (!applicant.gender || applicant.gender == null ) {
          setValue(`applicants[${index}].gender`, 'notprovided');
        }
      })      
      markComplete(currentStep, true);
    } else if ((!isComplete && !allAffiliateFieldsFilled) && completionRef.current) {
      completionRef.current = false;
      markComplete(currentStep, false);
    }
  }, [formData]);

  useEffect(() => {
    if (provinces.length > 0 && formData?.appInfo?.provinceId) {
      setValue('appInfo.provinceId', formData.appInfo.provinceId, { shouldValidate: true });
    }
  }, [provinces, formData?.appInfo?.provinceId, setValue]); 

  useEffect(() => {
    if (carriers.length > 0 && formData?.appInfo?.carrierId) {
      setValue('appInfo.carrierId', formData.appInfo.carrierId, { shouldValidate: true });
      setValue('appInfo.carrierName', (carriers.find(({ id }) => id == formData.appInfo.carrierId) as any)?.carrierName, { shouldValidate: true });
    }
    const carrier: any = carriers.find(({ id }) => id == formData.appInfo.carrierId);
    if (carrier?.photo?.url) {
      setLogoUrl(carrier?.photo?.url);
    } else {
      setLogoUrl('/images/eauclaire/ECO_Logo_Golden.svg');
    }    
  }, [carriers, formData?.appInfo?.carrierId, setValue]);

  const handleSearch = (term: string) => {
    console.log('searching for', term); 
    if (term.length > 2) {
      const results = clients.filter((client: any) =>
        `${client.firstName} ${client.lastName}`.toLowerCase().includes(term.toLowerCase())
      );
      setSearchResults(results);
    } else {
      setSearchResults([]);
    }
  };

  const handleClientSelect = (client: any) => {
    setValue(`applicants[${currentApplicantIndex}].firstName`, client.firstName);
    setValue(`applicants[${currentApplicantIndex}].lastName`, client.lastName);
    setValue(`applicants[${currentApplicantIndex}].dateOfBirth`, client.dateOfBirth);
    setValue(`applicants[${currentApplicantIndex}].gender`, client.gender.toLowerCase());
    setValue(`applicants[${currentApplicantIndex}].clientId`, client.id);
    setSearchTerm('');
    setSearchResults([]);
    setDialogOpen(false);  // Close the dialog after selection
  };
  // console.log('Applicants:', formData.applicants);
  return (
    <ColContainer cols="1:1:1:1">
      <RowContainer className="flex flex-row justify-between items-center space-x-4">
        <Select
          label="Carrier"
          name="appInfo.carrierId"
          defaultOption='Select Carrier'
          register={register}
          options={carriers.map(({ id, carrierName }) => ({ name: carrierName, id: id }))}
          required={true}
          className='max-w-[12rem]'
          isEditable={isEditable}
        />
        <Input
          label="Application Number"
          name="appInfo.appNumber"
          register={register}
          type="text"
          required={true}
          className='max-w-[12rem]'
          isEditable={isEditable}
        />
        <Input
          label={formData?.caseType == 'Insurance' ? 'Policy Number' : 'Account Number'}
          name="appInfo.policyAccountNumber"
          register={register}
          type="text"
          required={false}
          isEditable={isEditable}
        />
        <Select
          label="Province"
          name="appInfo.provinceId"
          register={register}
          defaultOption='Select Province'
          options={provinces.map(({ id, name }) => ({ name, id }))}
          required={true}
          isEditable={isEditable}
        />
        <Select
          label="Type"
          name="appInfo.type"
          register={register}
          defaultOption='Select Type'
          options={[
            { name: 'Electronic', id: 'Electronic' },
            { name: 'First Piece of Business (FPB)', id: 'First Piece of Business (FPB)' },
            { name: 'Paper', id: 'Paper' }
          ]}
          required={true}
          isEditable={isEditable}
        />        
      </RowContainer>
      {isCarrierComplete && (
        <RowContainer className='min-w-[25rem] space-y-0 mt-4' >
          <p>Number of applicants: {fields.length}</p>
        {fields.map((field: any, index) => (
          <div id={`client_` + field.id} key={field.id} className='h-fit'>
            <RowContainer className="relative flex flex-row just-between items-center space-x-6 flex-wrap">
              {(!formData.applicants[index].clientId || formData.applicants[index].clientId === null) ? (
                <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
                  <DialogTrigger asChild>
                    <RoundButton
                      icon={MdSearch}
                      className="bg-transparent text-primary px-2 py-2 rounded-md"
                      onClick={() => {setCurrentApplicantIndex(index); setDialogOpen(true);}}
                      hint="Search for a client"
                      isEditable={isEditable}
                    />
                  </DialogTrigger>
                  <DialogContent className="sm:max-w-[425px]">
                    <DialogHeader>
                      <DialogTitle>Search client in your contact list</DialogTitle>
                      <Link href={`/dashboard/myclient/${advisor}`}>
                        <p className='text-sm text-blue-500 und'>You need to define client in your contact list first!!</p>
                      </Link>
                    </DialogHeader>
                    <SearchBox
                      label="Client"
                      onSearch={handleSearch}
                      onSelect={handleClientSelect}
                      results={searchResults}
                      isEditable={isEditable}
                    />
                  </DialogContent>
                </Dialog>
              ) : (
                <>
                  <Input
                    label="First Name"
                    name={`applicants[${index}].firstName`}
                    type="text"
                    register={register}
                    required={true}
                    errors={errors}
                    isEditable={false}
                  />
                  <Input
                    label="Last Name"
                    name={`applicants[${index}].lastName`}
                    type="text"
                    register={register}
                    required={true}
                    errors={errors}
                    isEditable={false}
                  />
                  {(formData?.caseType == "Insurance" || formData?.caseType == "Investment") && ( 
                    <>
                      <Input
                        label="Date of Birth"
                        name={`applicants[${index}].dateOfBirth`}
                        type="date"
                        register={register}
                        required={true}
                        errors={errors}
                        isEditable={false}
                      />
                      <Select
                        label="Gender"
                        name={`applicants[${index}].gender`}
                        defaultOption='Select'
                        options={[{ name: 'Male', id: 'male' }, { name: 'Female', id: 'female' }]}
                        register={register}
                        required={true}
                        isEditable={false}
                        className={`w-[6rem]`}
                      />
                    </>
                  )}
                </>
              )}
              <input type="hidden" {...register(`applicants[${index}].clientId`)} />
              {(formData?.caseType == "Insurance" || formData?.caseType == "Investment") && formData?.applicants[`${index}`].clientId && ( 
                <>
                  <Switch
                    label="Owner?"
                    name={`applicants[${index}].isOwner`}
                    register={register}
                    isChecked={formData.applicants[index].isOwner}
                    isEditable={isEditable}
                  />
                  {formData?.appInfo?.carrierName != 'Brownstone Asset Management' && (
                    <Switch
                      label={formData?.caseType == "Insurance" ? "Is Insured ?" : "Is Annuitant?"}
                      name={`applicants[${index}].isInsuredAnnuitant`}
                      register={register}
                      isChecked={formData.applicants[index].isInsuredAnnuitant}
                      isEditable={isEditable}
                    />
                  )}
                </>
              )}
              {insuredAnnuitantWatchFields && insuredAnnuitantWatchFields[index] && formData?.caseType == "Insurance" && (
                <Switch
                  label="Smoking?"
                  name={`applicants[${index}].smoker`}
                  register={register}
                  isChecked={formData.applicants[index].smoker}
                  isEditable={isEditable}
                />              
              )}
              {(formData?.caseType == "Affiliate") && (
                <>
                  <Input
                    label="Email"
                    name={`applicants[${index}].email`}
                    type="email"
                    register={register}
                    required={true}
                    errors={errors}
                    isEditable={isEditable}  
                  />              
                  <Input
                    label="Phone"
                    name={`applicants[${index}].phone`}
                    type="tel"
                    register={register}
                    required={true}
                    errors={errors}
                    form={form}
                    isEditable={isEditable}
                  />
                  <Select
                    label="Gender"
                    name={`applicants[${index}].gender`}
                    className='hidden'
                    defaultOption='notprovided'
                    defaultValue='notprovided'
                    options={[
                      { name: 'notprovided', id: 'notprovided' }, 
                      { name: 'Male', id: 'male' }, 
                      { name: 'Female', id: 'female' }]}
                    register={register}
                    required={true}
                    isEditable={isEditable}
                  />                      
                </>
              )}
              <div className='absolute top-[-1.5rem] right-[-1.5rem]'>
                <RoundButton
                  type="button"
                  icon={IoCloseCircle}
                  className="bg-transparent text-danger px-2 py-2 rounded-md"
                  onClick={() => remove(index)}
                  hint="Remove this applicant"
                  isEditable={isEditable}
                />              
              </div>            
            </RowContainer>
          </div>
        ))}
        <RoundButton
          icon={MdAddCircle}
          type="button"
          className="bg-transparent text-primary px-2 pt-1 rounded-md h-[2.2rem]"
          onClick={() => {
            append({ firstName: '', lastName: '', dateOfBirth: null, gender: '', isInsuredAnnuitant: false, isOwner: false, smoker: false, clientId: null });
          }}
          hint="Add another applicant"
          isEditable={isEditable}
        />
        </RowContainer>
      )}
    </ColContainer>
  );
};

export default CarrierApplicant;                  