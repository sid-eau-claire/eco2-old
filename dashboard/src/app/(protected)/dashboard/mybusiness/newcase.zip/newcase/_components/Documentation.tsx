'use client'
import React, { useEffect } from 'react';
import { useFormContext } from 'react-hook-form';  // Import if needed
import { ColContainer, RowContainer } from '@/components/Containers';
import { motion } from 'framer-motion';
import { FilesInput } from '@/components/Input';

const DocumentUploadForm =  ({ form, currentStep, setCurrentStep, markComplete }: { form: any, currentStep: number, setCurrentStep: any, markComplete: any })=> {
  const { register, control, setValue, watch, formState: { errors, isSubmitting }, reset } = form;
  const docFormData = watch(['applicationDocuments', 'illustrationDocuments']);
  const formData = watch();
  useEffect(() => {
    if (docFormData.applicationDocuments?.length > 0 && docFormData.illustrationDocuments?.length > 0) {
      markComplete(currentStep, true);
    }
  }, [docFormData, markComplete]);

  console.log('formData', formData)
  return (
    <ColContainer cols="2:2:2:1" className='min-w-[25rem]'>
      <RowContainer>
        <FilesInput
          label="Application Documents"
          name="applicationDocuments"
          // register={register}
          setValue={setValue}  // Ensure setValue is passed
          defaultValue={docFormData.applicationDocuments} 
          accept="image/*,video/*,audio/*,.pdf,.doc,.docx"
          multiple={true}
          errors={errors}
          required={false}
        />
      </RowContainer>
      {(formData?.caseType == 'Insurance' || formData?.caseType == 'Investment') && (
        <RowContainer>
          <FilesInput
            label="Illustration Documents"
            name="illustrationDocuments"
            // register={register}
            setValue={setValue}  // Ensure setValue is passed
            defaultValue={docFormData.applicationDocuments} 
            accept="image/*,video/*,audio/*,.pdf,.doc,.docx"
            multiple={true}
            errors={errors}
            required={false}
          />
        </RowContainer>
      )}
      <RowContainer>
        <motion.button
          whileHover={{ scale: 1.1 }}
          whileTap={{ scale: 0.9 }}
          type="button"
          className='bg-primary hover:bg-blue-700 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline'
          onClick={() => markComplete(currentStep, true)}
        >
          Upload Documents
        </motion.button>
      </RowContainer>
    </ColContainer>
  );
};

export default DocumentUploadForm;
