'use client'
import React, { useEffect, useRef } from 'react';
import { useFieldArray } from 'react-hook-form';
import { Input, CInput, Select, Switch } from '@/components/Input';
import { ColContainer, RowContainer } from '@/components/Containers';
import {  motion } from 'framer-motion';
import Image from 'next/image';
import { RoundButton, LoadingButtonNP } from '@/components/Button';
import { getAdvisorNameList } from './../_actions/retrievedata';
import { twMerge } from 'tailwind-merge';
import { MdAddCircle } from "react-icons/md";
import { IoCloseCircle } from "react-icons/io5";
import {TypewriterEffectSmooth} from '@/components/ui/typewriter-effect'
import { set } from 'zod';
import {accessWithAuth} from '@/lib/isAuth';

const TypeAgent = ({ form, currentStep, setCurrentStep, markComplete, setSelectedSteps, isEditable }: { form: any, currentStep: number, setCurrentStep: any, markComplete:any, setSelectedSteps: any, isEditable?: boolean }) => {
  const [advisorList, setAdvisorList] = React.useState([]);
  const [is100Percentage, setIs100Percentage] = React.useState(false);
  const [yourProfileId, setYourProfileId] = React.useState(0);
  const completionRef = useRef(false);
  const loadSplitAgent = useRef(false);
  const { register, control, setValue, watch, formState: { errors, isSubmitting }, reset } = form;
  const splitAgents = watch('splitAgents[]');
  const formData = watch();
  const { fields, append, remove } = useFieldArray({
    control,
    name: 'splitAgents'
  });
  const [type, setType] = React.useState('');
  const [isSplitAgent, setIsSplitAgent] = React.useState(0);


  useEffect(() => {
    const fetchAdvisorList = async () => {
      const response = await getAdvisorNameList(); // Assume getAdvisorNameList fetches the advisor list
      setAdvisorList(response);
    }
    const fetchWritingAgentId = async () => {
      const response = await accessWithAuth();
      setValue('writingAgentId', response.user.data.profile.id);
      setYourProfileId(response.user.data.profile.id);
    }
    fetchAdvisorList();
    fetchWritingAgentId();

    // reset({
    //   splitAgents: formData.splitAgents || []
    // });
    // Explicitly append the splitAgents to fields array
    // if (formData.splitAgents) {
    //   formData.splitAgents.forEach((agent: any) => {
    //     append(agent);
    //   });
    // }
    // console.log('there')
  },[]);

  useEffect(() => {
    // console.log('fields', fields) 
    let totalPercentage = 0;
    splitAgents?.map((agent: any, index: number) => {
      if (agent.referralCode.length == 7 && agent.profileId == undefined) {
        advisorList.find((advisor: any) => {
          if (advisor.referralCode == agent.referralCode) {
            // setValue(`splitAgents[${index}].agent`, advisor.referralCode);
            setValue(`splitAgents[${index}].profileId`, advisor.id);
            setValue(`splitAgents[${index}].found`, 'Found');
            console.log('found', advisor)
          }
        });
      } else {
        if (agent.name != undefined) {
          agent.profileId = undefined
          agent.name = undefined
        }
      }
      totalPercentage += Number(agent.splitingPercentage);
    });
    if (totalPercentage == 100 && !completionRef.current) {
      markComplete(currentStep, true)
      completionRef.current = true;
      setIs100Percentage(true)
    } else if (totalPercentage != 100 && completionRef.current) {
      completionRef.current = false;      
      markComplete(currentStep, false);
    }
    // if (!loadSplitAgent.current && formData?.splitAgents?.length > 0) {
    //   formData?.splitAgents?.map((agent: any, index: number) => {
    //     // check if fields array if any items match with agent.profileId
    //     const found = fields.find((field: any) => field.profileId == agent.profileId);
    //     if (!found) {
    //       append(agent);
    //     }
    //   })
    //   loadSplitAgent.current = true;
    // } else {
      
    // }
    // console.log('totalPercentage', totalPercentage)
    
  }, [formData]);
  
  

  console.log('fields', fields)
  // useEffect(() => {
  //   const isComplete = formData?.appInfo?.carrierId && formData?.appInfo?.appNumber && formData?.appInfo?.provinceId && formData?.appInfo?.type;
  //   if (isComplete && !completionRef.current) {
  //     completionRef.current = true; // Mark as complete
  //     markComplete(true);
  //   } else if (!isComplete && completionRef.current) {
  //     completionRef.current = false; // Mark as incomplete
  //     markComplete(false);
  //   }
  // }, [formData]); // Depend only on formData

  // useEffect(() => {
  //   fields.forEach((field, index) => {
  //     const referralCode = watch(`splitAgents[${index}].referralCode`);
  //     if (referralCode && referralCode.length === 7) {
  //       let advisor: any = null;
  //       advisor = advisorList.find((a: any) => a.referralCode === referralCode);
  //       if (advisor) {
  //         setValue(`splitAgents[${index}].advisorName`, `${advisor.firstName} ${advisor.lastName}`);
  //       } else {
  //         setValue(`splitAgents[${index}].advisorName`, "Not found");
  //       }
  //     }
  //   });
  //   console.log('fields', fields)
  // }, [fields, watch, advisorList, setValue]);

  // console.log(advisorList);
  const handleCaseType = (type: string) => {
    setType(type);
    setValue('caseType', type);
    if (type == "Affiliate") {
      setSelectedSteps([true, false, true, true, true])
    }
  }
  // console.log(formData)
  // console.log('currentStep', currentStep)
  return (
    <div className='relative'>
            {/* <CInput
              label="Coverage Face Amount"
              name={`testing`}
              register={register}
              type="currency"
              required={true}
              className='max-w-[10rem]'
              form={form}
            />       */}
      <RowContainer className='min-w-[25rem] flex flex-col justify-start items-start'>
        <TypewriterEffectSmooth words='1. Please select the product type:' className='className="text-lg mb-4' />
        {/* <p className="text-lg mb-4">1. Please select the product type:</p> */}
        <div className='flex flex-row justify-center items-center space-x-8'>
          {['Insurance', 'Investment'].map((product) => (
            <motion.div
              key={product}
              initial={{ scale: 0, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              // exit={{ scale: 0, opacity: 0 }}
              transition={{ delay: 0, duration: 0.5 }}
              className={twMerge(`flex flex-col justify-center items-center`, (formData.caseType == product || formData.caseType == undefined) ? 'flex' : 'hidden')}
              whileHover={{ scale: 1.1 }}
              // whileTap={{ scale: 0.9 }}
              onClick={() => handleCaseType(product)}
            >
              <Image src={`/images/icon/${product.toLowerCase()}.webp`} alt='Agent' width={60} height={60} />
              <p className='font-semibold'>{product}</p>
            </motion.div>
          ))}
        </div>
      </RowContainer>

      {formData?.caseType && formData.caseType !== '' && (
        <RowContainer className='min-w-[25rem]'>
          {/* <p className="text-lg mb-4">Need split revenue?</p> */}
          <TypewriterEffectSmooth words='2. Need split revenue?' className='className="text-lg mb-4' />
          <div className='flex flex-row justify-start items-center space-x-8'>
            <Switch
              label="Yes"
              name="yesSplitAgent"
              isChecked={formData.isSplitAgent != undefined && formData.isSplitAgent}
              // onChange={() => {setIsSplitAgent(1); markComplete(false)}}
              onChange={() => {setValue('isSplitAgent', true); markComplete(currentStep, false)}}
              isEditable={true}
              hint="Check this box if you want to split the agent commission."
            />
            <Switch
              label="NO"
              name="noSplitAgent"
              isChecked={formData.isSplitAgent != undefined && !formData.isSplitAgent}
              // onChange={() => {setIsSplitAgent(2); markComplete(true)}}
              onChange={() => {setValue('isSplitAgent', false); setValue('splitAgents', []); setValue('writingAgentId', yourProfileId); markComplete(currentStep, true)}}
              isEditable={true}
              hint="Check this box if you want to split the agent commission."
            />
          </div>
        </RowContainer>
      )}

      {formData?.caseType && formData?.isSplitAgent && (
        <RowContainer className='relative min-w-[25rem]'>
          <TypewriterEffectSmooth words='3. Click Add button' className='text-lg mb-4' />
          {/* <div className='absolute -top-[1.5rem] -right-[2.2rem]'>
            <RoundButton
              icon={MdAddCircle}
              className="m-0 pt-0 bg-transparent text-primary rounded-md px-4 py-2 ml-0" 
              onClick={() => append({ agent: '', percentage: 0 })}
              hint="Add advisor to split revenue"
            />          
          </div> */}
          {fields.map((field, index) => (
            <div key={field.id} className='flex flex-row justify-between items-center space-x-4 '>
              <Input
                label={index == 0 ? "Writing Agent" : "Split Agent"}
                name={`splitAgents[${index}].referralCode`}
                register={register}
                required={true}
                errors={errors}
                // hint="Please input agent ECO CODE"
                placeholder='EXXXXXX'
                minLength={7}
                maxLength={7}
                className='w-[7rem]'
              />
              <Input
                label=""
                name={`splitAgents[${index}].found`}
                register={register}
                // required={true}
                disabled={true}
                errors={errors}
                className='-ml-[0.5rem] mt-[1.5rem] w-[5rem] border-none bg-transparent text-success'
              />
              {`splitAgents[${index}].referralCode` && `splitAgents[${index}].profileId` && (
                <Input
                  label="Split %"
                  name={`splitAgents[${index}].splitingPercentage`}
                  type="number"
                  register={register}
                  required={true}
                  errors={errors}
                  className='w-[5rem]'
                />
              )}
              <RoundButton
                className='bg-transparent text-danger px-2 py-2 rounded-md mx-4'
                onClick={() => remove(index)}
                icon={IoCloseCircle}
                hint="Remove this agent"
              />
            </div>
          ))}
          <RoundButton
            icon={MdAddCircle}
            className="m-0 pt-0 bg-transparent text-primary rounded-md px-4 py-2 ml-0" 
            onClick={() => append({ agent: '', percentage: 0 })}
            hint="Add advisor to split revenue"
          />
        </RowContainer>
      )}
    </div>
  );
};

export default TypeAgent;
