'use client'
import React, { useEffect, useRef } from 'react';
import { useFieldArray } from 'react-hook-form';
import { Input, Switch, Select } from '@/components/Input';
import { ColContainer, RowContainer } from '@/components/Containers';
import { motion } from 'framer-motion';
import { RoundButton } from '@/components/Button';
import { MdAddCircle } from "react-icons/md";
import { IoCloseCircle } from "react-icons/io5";

const ComplianceForm =  ({ form, currentStep, setCurrentStep, markComplete }: { form: any, currentStep: number, setCurrentStep: any, markComplete: any }) => {
  const { register, control, setValue, watch, getValues, formState: { errors, isSubmitting }, reset } = form;
  const completionRef = useRef(false);
  const formData = watch();
  const watchAnalysis = watch('compliance.analysis');
  const watchReason = watch('compliance.reason');
  const watchDisclosure = watch('compliance.disclosure');
  const watchQA = watch('compliance.QA');
  const { fields, append, remove } = useFieldArray({
    control,
    name: 'compliance.QA'
  });

  // useEffect(() => {
  //   if (formData?.compliance?.analysis == true 
  //       && 
  //     formData?.compliance?.reason == true 
  //       && 
  //     formData?.compliance?.disclosure == true 
  //       &&
  //     completionRef.current == false) {
  //     completionRef.current = true;
  //     markComplete(true);
  //   } else {
  //     completionRef.current = false;
  //     markComplete(false);
  //   }
  // }, [watchAnalysis, watchReason, watchDisclosure, watchQA]);
  useEffect(() => {
    console.log('here')
    // const isComplete = formData?.compliance?.analysis  && formData?.compliance?.reason  && formData?.compliance?.disclosure && formData?.compliance?.QA.every((qa: any) => qa.question && qa.answer);
    const isComplete = formData?.compliance?.analysis  && formData?.compliance?.reason  && formData?.compliance?.disclosure && formData?.compliance?.QA.every((qa: any) => qa.answer != '');
    console.log(isComplete)
    if (isComplete && !completionRef.current) { 
      completionRef.current = true;
      markComplete(currentStep, true);
    } else if (!isComplete && completionRef.current) {
      completionRef.current = false;
      markComplete(currentStep, false);
    } 
  // }, [watchAnalysis, watchReason, watchDisclosure, watchQA]);  
  }, [formData]);  


  useEffect(() => {
    const questions = [
      "What is the purpose of this insurance sale?",
      "How was the coverage determined or calculated?"
    ];
  
    questions.forEach((question, index) => {
      setValue(`compliance.QA[${fields.length + index}].question`, question);
    });
  }, [fields.length, setValue]);
  console.log('formData', formData) 
  return (
    <div className='space-y-4'>
      <ColContainer cols="3:3:3:1" className='min-w-[25rem]'>
        <RowContainer className='col-span-1'>
          <h3 className="text-lg font-semibold mb-4">Confirm compliances</h3>
          <Switch
            label="Analysis Completed?"
            name="compliance.analysis"
            isChecked={formData?.compliance?.analysis}
            register={register}
            isEditable={true}
          />
          <Switch
            label="Reason Documented?"
            name="compliance.reason"
            isChecked={formData?.compliance?.reason}
            register={register}
            isEditable={true}
          />
          <Switch
            label="Disclosure Provided?"
            name="compliance.disclosure"
            isChecked={formData?.compliance?.disclosure}
            register={register}
            isEditable={true}
          />
        </RowContainer>
        <RowContainer className='col-span-2'>
          <h3 className="text-lg font-semibold mb-4">QA Questions</h3>
          {formData?.caseType == 'Insurance' && (
            <>
              <div className="flex flex-col space-y-2 bg-transparent">
                <Input
                  label="Question"
                  name={`compliance.QA[0].question`}
                  type="text"
                  register={register}
                  required={true}
                  errors={errors}
                  defaultValue="What is the purpose of this insurance sale?"
                  isEditable={false}
                />
                <Input
                  label="Answer"
                  name={`compliance.QA[0].answer`}
                  type="text"
                  register={register}
                  required={true}
                  errors={errors}
                />
              </div>
              <div className="flex flex-col space-y-2">
                <Input
                  label="Question"
                  name={`compliance.QA[1].question`}
                  type="text"
                  register={register}
                  required={true}
                  errors={errors}
                  defaultValue="How was the coverage determined or calculated?"
                  isEditable={false}
                />
                <Input
                  label="Answer"
                  name={`compliance.QA[1].answer`}
                  type="text"
                  register={register}
                  required={true}
                  errors={errors}
                />
              </div>
            </>
          )}
          {formData?.caseType == 'Investment' && (
            <>
              <Input
                label="Question"
                name={`compliance.QA[0].question`}
                type="hidden"
                register={register}
                required={true}
                errors={errors}
                defaultValue="What is the purpose of this insurance sale?"
                isEditable={false}
              />
              <Select
                label="Investment Objective Tolerance"
                name={`compliance.QA[0].answer`}
                register={register}
                required={true}
                errors={errors}
                isEditable={true}
                defaultValue="Select Objective"
                options={[
                  { id: 'Growth', name: 'Growth' },
                  { id: 'Income', name: 'Income' }
                ]}
              />
              <Input
                label="Question"
                name={`compliance.QA[1].question`}
                type="hidden"
                register={register}
                required={true}
                errors={errors}
                defaultValue="How was the coverage determined or calculated?"
                isEditable={false}
              />              
              <Select
                label="Investment Risk Tolerance"
                name={`compliance.QA[1].answer`}
                register={register}
                required={true}
                errors={errors}
                isEditable={true}
                defaultValue="Select Risk Tolerance"
                options={[
                  { id: 'High', name: 'High' },
                  { id: 'Medium', name: 'Medium' },
                  { id: 'Low', name: 'Low' }
                ]}
              />
            </>
          )}          
        </RowContainer>
      </ColContainer>
    </div>
  );
};

export default ComplianceForm;
