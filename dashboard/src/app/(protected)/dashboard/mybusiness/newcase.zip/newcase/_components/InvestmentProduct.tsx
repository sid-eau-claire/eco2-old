'use client'
import React, { useEffect, useRef, useState } from 'react';
import { useFormContext, useFieldArray } from 'react-hook-form';
import { Input, CInput, Select, Switch } from '@/components/Input';
import { ColContainer, RowContainer } from '@/components/Containers';
import { RoundButton } from '@/components/Button';
import { MdAddCircle } from "react-icons/md";
import { IoCloseCircle } from "react-icons/io5";
import { getFundCategory, getInvestmentFeeType } from '../_actions/retrievedata';
import { getCommissionDistributionGS } from '../_actions/retrievedata';


function calculateRecurringDepositsPerYear(frequency: string) {
  const frequencies: { [key: string]: number } = {
      'Weekly': 52,
      'Bi-Weekly': 26,
      'Twice a month': 24,
      'Monthly': 12,
      'Quarterly': 4
  };

  return frequencies[frequency] || 0;
}

const InvestmentProduct = ({ form, currentStep, setCurrentStep, markComplete, isEditable }: { form: any, currentStep: number, setCurrentStep: any, markComplete: any, isEditable?: boolean }) => {
    const [fundCategories, setFundCategories] = useState<any[]>([]);
    const [isNoCategory, setIsNoCategory] = useState<boolean>(false);
    const [investmentFeeTypes, setInvestmentFeeTypes] = useState<any[]>([]);
    const [commissionDistributionGS, setCommissionDistributionGS] = React.useState<any>(null);
    const [corporateMarginPercentInvestment, setCorporateMarginPercentInvestment] = React.useState<number>(0);

    const { register, control, setValue, watch, resetField, getValues } = form;
    const formData = watch();
    const completionRef = useRef(false);
    const firstAccessRef = useRef(false);
    const { fields, append, remove } = useFieldArray({
        control,
        name: 'appInvProducts'
    });

    useEffect(() => {
        const fetchGS = async () => {
            const response = await getCommissionDistributionGS();
            setCommissionDistributionGS(response);
            setCorporateMarginPercentInvestment(response.find((item: any) => item.name === 'corporateMarginPercentInvestment')?.value);
        };
        fetchGS();
    }, []);

    useEffect(() => {
        const fetchFundCategories = async () => {
            const response = await getFundCategory(formData?.appInfo?.carrierId);
            setIsNoCategory(response[0]?.name == 'nocategory');
            setFundCategories(response);
        };
        const fetchInvestmentFeeType = async () => {
            const response = await getInvestmentFeeType();
            setInvestmentFeeTypes(response);
        };
        fetchFundCategories();
        fetchInvestmentFeeType();
    }, [formData?.appInfo?.carrierId]);

    useEffect(() => {
      // console.log('here')
      // let totalEstFieldRevenue = 0;
      fields.forEach((field: any, index) => { // Update the type of the 'field' parameter to include 'estFieldRevenue'
        const isLumpSum = getValues(`appInvProducts[${index}].isLumpSum`);
        const isRecurring = getValues(`appInvProducts[${index}].isRecurring`);
        const lumpSumDeposit = Number(getValues(`appInvProducts[${index}].lumpSumDeposit`));
        const recurringDeposit = Number(getValues(`appInvProducts[${index}].recurringDeposit`));
        const frequency = getValues(`appInvProducts[${index}].frequency`);
        const feeTypeId = getValues(`appInvProducts[${index}].feeTypeId`);
        const feePercentage = Number(investmentFeeTypes.find((investmentFeeType: any) => investmentFeeType.id == feeTypeId)?.feePercentage);
        const lumpSumEstFieldRevenue = isLumpSum ? lumpSumDeposit * feePercentage * (1 - corporateMarginPercentInvestment / 100) : 0; 
        const recurringEstFieldRevenue = isRecurring ? recurringDeposit * calculateRecurringDepositsPerYear(frequency)  * feePercentage * (1 - corporateMarginPercentInvestment / 100) : 0;
        const lumpSumAUM = isLumpSum ? lumpSumDeposit : 0
        const recurringAUM = isRecurring ? recurringDeposit * calculateRecurringDepositsPerYear(frequency) : 0
        const annualAUM = lumpSumAUM + recurringAUM
        // setValue(`appInvProducts[${index}].annualAUM`, annualAUM);
        const estFieldRevenue = lumpSumEstFieldRevenue + recurringEstFieldRevenue;
        // const estFieldRevenue = deposit * feePercentage * (1 - corporateMarginPercentInvestment / 100);

        // console.log('feeTypeId', feeTypeId)
        // console.log('lumpSumDeposit', lumpSumDeposit)
        // console.log('recurringDeposit', recurringDeposit)
        // console.log('feePercentage', feePercentage)
        // console.log('lumpSumEstFieldRevenue', lumpSumEstFieldRevenue)
        // console.log('recurringEstFieldRevenue', recurringEstFieldRevenue)

        // console.log('estFieldRevenue', estFieldRevenue)
        // console.log('field.estFieldRevenue', field.estFieldRevenue)
        // console.log('appInvProducts', `appInvProducts[${index}].estFieldRevenue`)
        // setValue(`appInvProducts[${index}].annualAUM`, 
        //   (lumpSumDeposit + recurringDeposit ) 
        // );
        if (!isNaN(estFieldRevenue) && field.estFieldRevenue != estFieldRevenue) {
          const currentEstFieldRevenue = getValues(`appInvProducts[${index}].estFieldRevenue`);
          const formattedEstFieldRevenue = estFieldRevenue.toFixed(2);
          // console.log('currentEstFieldRevenue', currentEstFieldRevenue)
            // setValue(formData.appInvProducts[index].estFieldRevenue, estFieldRevenue);
          if (currentEstFieldRevenue != formattedEstFieldRevenue) {
            setValue(`appInvProducts[${index}].estFieldRevenue`, formattedEstFieldRevenue, { shouldDirty: true });
          }
          const currentAnnualAUM = getValues(`appInvProducts[${index}].annualAUM`);
          const formattedAnnualAUM = annualAUM.toFixed(2);
          if (currentAnnualAUM != formattedAnnualAUM) {
            setValue(`appInvProducts[${index}].annualAUM`, formattedAnnualAUM, { shouldDirty: true });
          }
          // setValue(`appInvProducts[${index}].annualAUM`, 
          //   (lumpSumDeposit + recurringDeposit ) 
          // );          
        }
      });

      const totalEstFieldRevenue = formData.appInvProducts.reduce((total: number, product: any) => {
          return total + parseFloat(product.estFieldRevenue || 0);
      }, 0);
      const totalAnnualAUM = formData.appInvProducts.reduce((total: number, product: any) => {
          return total + parseFloat(product.annualAUM || 0);
      }, 0)
      const currentTotalEstFieldRevenue = getValues('totalEstFieldRevenue');
      const formattedTotalRevenue = totalEstFieldRevenue.toFixed(2);
      if (currentTotalEstFieldRevenue !== formattedTotalRevenue) {
          setValue('totalEstFieldRevenue', formattedTotalRevenue, { shouldDirty: true });
      }
      const currentTotalAnnualAUM = getValues('totalAnnualAUM');
      const formattedTotalAnnualAUM = totalAnnualAUM.toFixed(2);
      if (currentTotalAnnualAUM !== formattedTotalAnnualAUM) {
          setValue('totalAnnualAUM', formattedTotalAnnualAUM, { shouldDirty: true });
      }
    }, [fields.map((field, index) => getValues(`appInvProducts[${index}].lumpSumDeposit`)),
        fields.map((field, index) => getValues(`appInvProducts[${index}].recurringDeposit`)), 
        fields.map((field, index) => getValues(`appInvProducts[${index}].feeTypeId`)),]);

    //For iCPM fee type
    useEffect(() => {
      // const isNoCategory = (fundCategories[0]?.name == 'nocategory')
      fields.forEach((product: any, index: number) => {
        console.log('fundCategories', fundCategories)
        if (isNoCategory && `appInvProducts[${index}].categoryId` != fundCategories[0]?.id ) {
          console.log('nocategory')
          product.categoryId = fundCategories[0]?.id
          // setValue(`appInvProducts[${index}].categoryId`, fundCategories[0]?.id , { shouldDirty: true });
        }
      })
    }, [fields.map((field, index) => getValues(`appInvProducts[${index}].registrationType`))]);    

    useEffect(() => {
        if (formData?.appInvProducts?.length > 0) {
            const allFieldsFilled = formData?.appInvProducts.every((field: any) =>
                field.applicantIndex !== undefined &&
                field.registrationType !== '' &&
                field.categoryId !== '' &&
                field.feeTypeId !== '' &&
                field.lumpSumDeposit !== 0 &&
                field.lumpRecurringDeposit !== 0 &&
                field.estFieldRevenue !== 0 &&
                formData?.estSettledDays !== ''
            );
            if (allFieldsFilled && !completionRef.current) {
                completionRef.current = true;
                markComplete(currentStep, true);
            } else if (!allFieldsFilled && completionRef.current) {
                completionRef.current = false;
                markComplete(currentStep, false);
            }
        }
    }, [formData, currentStep, markComplete]);

    const handleAddProduct = (applicantIndex: number, fieldIndex?: number) => {
        let currentCount = 0;
        if (fieldIndex !== undefined) {
            currentCount = fieldIndex;
        } else {
            currentCount = formData?.appInvProducts?.length || 0;
        }
        append({
            applicantIndex,
            fieldIndex: currentCount,
            registrationType: '',
            categoryId: '',
            frequency: '',
            deposit: 0,
            feeTypeId: '',
            estFieldRevenue: 0
        });
    };
    if (formData && !firstAccessRef.current && formData?.applicants && formData?.applicants?.length > 0) {
      firstAccessRef.current = true;
      const temp = formData.appInsProducts?.filter((product: any) =>
        formData.applicants.some((applicant: any, index: number) => index == product.applicantIndex)
      );    
      setValue('appInsProducts', temp, { shouldDirty: true })
      formData.applicants?.forEach((applicant: any, index: number) => {
        if (formData?.appInsProducts?.some((product: any) => product.applicantIndex == index)) return;
        handleAddProduct(index, index);
      })
    }

    const handleRemoveProduct = (index: number) => {
        const updatedProducts = fields.filter((_, idx) => idx !== index);
        const productsWithUpdatedIndices = updatedProducts.map((product, idx) => ({
            ...product,
            fieldIndex: idx  // Correct the fieldIndex to match the new array order
        }));
        resetField('appInvProducts', {
            defaultValue: productsWithUpdatedIndices, // Set the updated products as new default values
        });
    };

    const groupedFields = formData?.appInvProducts?.reduce((acc: any, product: any) => {
        const index = product.applicantIndex;
        if (!acc[index]) {
            acc[index] = [];
        }
        acc[index].push(product);
        return acc;
    }, {});

    return (
        <ColContainer cols="1:1:1:1">
            {groupedFields && Object.keys(groupedFields).map((groupIndex, aindex) => (
                <RowContainer key={aindex} className='pb-0'>
                    {groupedFields[groupIndex] && groupedFields[groupIndex][0] && (
                        <p className="font-semibold pb-[1rem]">Applicant {aindex + 1}: {formData?.applicants[groupIndex]?.firstName} {formData?.applicants[groupIndex]?.lastName}</p>
                    )}
                    {groupedFields[groupIndex] && groupedFields[groupIndex].map((field: any, index: number) => (
                        <div key={field.id} className='relative'>
                            <div className='absolute top-[0rem] right-[0rem]'>
                                <RoundButton
                                    icon={IoCloseCircle}
                                    className="bg-transparent text-danger px-2 py-2 rounded-md"
                                    onClick={() => { if (groupedFields[groupIndex].length > 1) { handleRemoveProduct(field.fieldIndex) } }}
                                    hint="Remove this product"
                                    isEditable={isEditable}
                                />
                            </div>
                            <RowContainer className='grid grid-cols-4 gap-x-2 items-center'>
                                <Select
                                    label="Registration Type"
                                    name={`appInvProducts[${index}].registrationType`}
                                    register={register}
                                    defaultOption='Select Registration Type'
                                    options={[
                                        { id: 'RRSP', name: 'RRSP' },
                                        { id: 'RRSP - Spousal', name: 'RRSP - Spousal' },
                                        { id: 'TFSA', name: 'TFSA' },
                                        { id: 'RESP', name: 'RESP' },
                                        { id: 'LIRA/PENSIONS', name: 'LIRA/PENSIONS' },
                                        { id: 'RDSP', name: 'RDSP' },
                                        { id: 'Non-Registered', name: 'Non-Registered' },
                                        { id: 'FHSA', name: 'FHSA' },
                                    ]}
                                    required={true}
                                    className='max-w-[15rem]'
                                    isEditable={isEditable}
                                />
                                {formData?.appInvProducts[index]?.registrationType != '' && fundCategories?.length > 0 && !isNoCategory && (
                                  <Select
                                    label="Category ID"
                                    name={`appInvProducts[${index}].categoryId`}
                                    register={register}
                                    defaultOption='Select Category'
                                    options={fundCategories.map((fundCategory: any, index: number) => ({id: fundCategory.id, name: fundCategory.name}))} // This should be fetched and set from `api::fundcategorytype.fundcategorytype`
                                    required={true}
                                    isEditable={isEditable}
                                  />
                                )}
                                {formData?.appInvProducts[index]?.categoryId != '' && investmentFeeTypes?.length > 0 && (
                                  <Select
                                    label="Fee Type ID"
                                    name={`appInvProducts[${index}].feeTypeId`}
                                    register={register}
                                    defaultOption='Select Fee Type'
                                    options={investmentFeeTypes.filter((investmentFeeType: any )=> investmentFeeType?.fundCategoryTypeId?.id == formData?.appInvProducts[index]?.categoryId ).map(
                                      (investmentFeeType: any) => ({id: investmentFeeType.id, name: investmentFeeType.name}))}
                                    required={true}
                                    isEditable={isEditable}
                                  />
                                )}
                                {( formData?.appInvProducts[index]?.feeTypeId != '') && isNoCategory && (
                                  <div className='col-span-4 flex flex-row justify-start items-center space-x-8'>
                                    <Input
                                      label="Management Fee Percentage"
                                      name={`appInvProducts[${index}].managementFee`}
                                      register={register}
                                      type="currency"
                                      required={true}
                                      className='max-w-[5rem]'
                                      form={form}
                                      isEditable={isEditable}
                                    />
                                  </div>
                                )}
                                {( formData?.appInvProducts[index]?.feeTypeId != '') && (
                                  <>
                                    <div className='grid grid-cols-3 col-span-3 items-center space-x-8'>
                                      <Switch
                                        label="Lump Sum?"
                                        defaultChecked={false}
                                        name={`appInvProducts[${index}].isLumpSum`}
                                        register={register}
                                        isChecked={formData?.appInvProducts[index]?.isLumpSum}
                                        isEditable={isEditable}
                                      />
                                      {formData?.appInvProducts[index]?.isLumpSum ? (
                                        <CInput
                                          label="Lump Sum Deposit"
                                          name={`appInvProducts[${index}].lumpSumDeposit`}
                                          register={register}
                                          type="currency"
                                          required={true}
                                          className='w-[11rem]'
                                          form={form}
                                          isEditable={isEditable}
                                        />                                      
                                      ):(<div className='h-[4.75rem]'></div>)}
                                    </div>
                                      <p className='text-end'>
                                        {formData?.appInvProducts[index]?.lumpSumDeposit && formData?.appInvProducts[index]?.feeTypeId && formData?.appInvProducts[index]?.lumpSumDeposit > 0 && formData?.appInvProducts[index]?.feeTypeId > 0 ? 
                                          `AUM: $${formData?.appInvProducts[index]?.lumpSumDeposit}` : ''
                                        } 
                                      </p>
                                  </>
                                )}
                                {( formData?.appInvProducts[index]?.feeTypeId != '') && (
                                  <>
                                    <div className='grid grid-cols-3 col-span-3 items-center space-x-8'>
                                      <Switch
                                        label="Recurring?"
                                        defaultChecked={false}
                                        name={`appInvProducts[${index}].isRecurring`}
                                        register={register}
                                        isChecked={formData?.appInvProducts[index]?.isRecurring}
                                        isEditable={isEditable}
                                      />
                                      {formData?.appInvProducts[index]?.isRecurring ? (
                                        <Select
                                          label="Frequency"
                                          name={`appInvProducts[${index}].frequency`}
                                          register={register}
                                          defaultOption='Select Frequency'
                                          options={[
                                            { id: 'Weekly', name: 'Weekly' },
                                            { id: 'Bi-Weekly', name: 'Bi-Weekly' },
                                            { id: 'Twice a month', name: 'Twice a month' },
                                            { id: 'Monthly', name: 'Monthly' },
                                            { id: 'Quarterly', name: 'Quarterly' },
                                            // Add the rest of your frequencies here
                                          ]}
                                          required={true}
                                          className='w-[11rem]'
                                          isEditable={isEditable}
                                        />                                     
                                      ):(<div className='h-[4.75rem]'></div>)}
                                      {formData?.appInvProducts[index]?.frequency && formData?.appInvProducts[index]?.isRecurring ? (
                                        <CInput
                                          label="Recurring deposit"
                                          name={`appInvProducts[${index}].recurringDeposit`}
                                          register={register}
                                          type="currency"
                                          required={true}
                                          className='max-w-[10rem]'
                                          form={form}
                                          isEditable={isEditable}
                                        />                                      
                                      ):(<div className='h-[4.9rem]'></div>)}
                                    </div>
                                    <p className='text-end'>
                                      {formData?.appInvProducts[index]?.recurringDeposit && formData?.appInvProducts[index]?.feeTypeId && formData?.appInvProducts[index]?.recurringDeposit > 0 && formData?.appInvProducts[index]?.feeTypeId > 0 ? 
                                        `AUM: $${formData?.appInvProducts[index]?.recurringDeposit}` : ''
                                      }
                                    </p>
                                  </>
                                )}
                                {(formData?.appInvProducts[index]?.lumpSumDeposit || formData?.appInvProducts[index]?.recurringDeposit   )&& (
                                  <div className='col-span-3 flex flex-row justify-start items-center'>
                                    <div></div><div></div>
                                    <CInput
                                      label="First Year Estimated Revenue"
                                      name={`appInvProducts[${index}].estFieldRevenue`}
                                      type="currency"
                                      register={register}
                                      required={true}
                                      className='max-w-[10rem]'
                                      isEditable={false}
                                      form={form}
                                    />
                                  </div>
                                )}
                            </RowContainer>
                        </div>
                    ))}
                    <RoundButton
                        icon={MdAddCircle}
                        className="bg-transparent text-primary px-4 py-2 rounded-md"
                        onClick={() => handleAddProduct(aindex)}  // Assuming the default applicantIndex; you might want to choose differently or set dynamically
                        hint="Add another product"
                        isEditable={isEditable}
                    />
                </RowContainer>
            ))}
          <div className='flex flex-row justify-end items-center mt-[1rem] space-x-4'>
            <Select
              label="Est. Settled Days"
              name={`estSettledDays`}
              defaultOption='Select Days'
              register={register}
              options={[{name: '30 Days', id: '30'},{name: '60 Days', id: '60'},{name: '90 Days', id: '90'} ]}
              required={true}
              className='max-w-[15rem]'
              isEditable={isEditable}
            />
            <CInput
              label="Total First Year Estimated Revenue"
              name={`totalEstFieldRevenue`}
              register={register}
              type="currency"
              required={false}
              className='max-w-[15rem] mb-0'
              form={form}
              isEditable={false}
              disabled
            />        
          </div>  
        </ColContainer>
    );
};

export default InvestmentProduct;
